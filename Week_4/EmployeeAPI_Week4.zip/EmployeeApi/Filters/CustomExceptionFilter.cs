using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using System; 
using System.IO;

namespace EmployeeApi.Filters 
{
    public class CustomExceptionFilter : IExceptionFilter
    {
        public void OnException(ExceptionContext context)
        {
            var exceptionDetails = $"[{DateTime.Now}] {context.Exception.Message}{Environment.NewLine}";
            File.AppendAllText("logs.txt", exceptionDetails);

            context.Result = new ObjectResult("Internal server error occurred.")
            {
                StatusCode = 500
            };
        }
    }
}
